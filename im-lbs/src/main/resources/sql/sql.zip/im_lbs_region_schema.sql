-- ==========================================
-- 1. 省份表 (Province)
-- ==========================================
CREATE TABLE IF NOT EXISTS im_ibs_china_province
(
    id
    BIGINT
    PRIMARY
    KEY
    GENERATED
    BY
    DEFAULT AS
    IDENTITY,
    code
    BIGINT
    NOT
    NULL,
    name
    VARCHAR
(
    100
) NOT NULL,
    short_name VARCHAR
(
    50
), -- 增加简称字段，如"京"
    lat DOUBLE PRECISION,
    lng DOUBLE PRECISION,
    CONSTRAINT uk_province_code UNIQUE
(
    code
) -- 确保代码唯一，供下级引用
    );

-- 添加注释
COMMENT
ON TABLE im_ibs_china_province IS '中国行政区划-省份表';
COMMENT
ON COLUMN im_ibs_china_province.id IS '主键ID';
COMMENT
ON COLUMN im_ibs_china_province.code IS '行政区划代码(例如:110000)';
COMMENT
ON COLUMN im_ibs_china_province.name IS '名称';
COMMENT
ON COLUMN im_ibs_china_province.short_name IS '简称';
COMMENT
ON COLUMN im_ibs_china_province.lat IS '纬度';
COMMENT
ON COLUMN im_ibs_china_province.lng IS '经度';

-- ==========================================
-- 2. 城市表 (City)
-- ==========================================
CREATE TABLE IF NOT EXISTS im_ibs_china_city
(
    id
    BIGINT
    PRIMARY
    KEY
    GENERATED
    BY
    DEFAULT AS
    IDENTITY,
    province_code
    BIGINT
    NOT
    NULL,
    code
    BIGINT
    NOT
    NULL,
    name
    VARCHAR
(
    100
) NOT NULL,
    lat DOUBLE PRECISION,
    lng DOUBLE PRECISION,
    CONSTRAINT uk_city_code UNIQUE
(
    code
),
    -- 外键关联省份表 (关联的是code而不是id，方便数据导入)
    CONSTRAINT fk_city_province FOREIGN KEY
(
    province_code
) REFERENCES im_ibs_china_province
(
    code
) ON DELETE CASCADE
    );

-- 索引
CREATE INDEX idx_city_province_code ON im_ibs_china_city (province_code);

-- 添加注释
COMMENT
ON TABLE im_ibs_china_city IS '中国行政区划-城市表';
COMMENT
ON COLUMN im_ibs_china_city.province_code IS '所属省份代码';
COMMENT
ON COLUMN im_ibs_china_city.code IS '行政区划代码';

-- ==========================================
-- 3. 区县表 (County/District)
-- ==========================================
CREATE TABLE IF NOT EXISTS im_ibs_china_county
(
    id
    BIGINT
    PRIMARY
    KEY
    GENERATED
    BY
    DEFAULT AS
    IDENTITY,
    city_code
    BIGINT
    NOT
    NULL,
    code
    BIGINT
    NOT
    NULL,
    name
    VARCHAR
(
    100
) NOT NULL,
    lat DOUBLE PRECISION,
    lng DOUBLE PRECISION,
    CONSTRAINT uk_county_code UNIQUE
(
    code
),
    CONSTRAINT fk_county_city FOREIGN KEY
(
    city_code
) REFERENCES im_ibs_china_city
(
    code
) ON DELETE CASCADE
    );

-- 索引
CREATE INDEX idx_county_city_code ON im_ibs_china_county (city_code);

-- 添加注释
COMMENT
ON TABLE im_ibs_china_county IS '中国行政区划-区县表';
COMMENT
ON COLUMN im_ibs_china_county.city_code IS '所属城市代码';

-- ==========================================
-- 4. 乡镇/街道表 (Town/Street)
-- ==========================================
CREATE TABLE IF NOT EXISTS im_ibs_china_town
(
    id
    BIGINT
    PRIMARY
    KEY
    GENERATED
    BY
    DEFAULT AS
    IDENTITY,
    county_code
    BIGINT
    NOT
    NULL,
    code
    BIGINT
    NOT
    NULL,
    name
    VARCHAR
(
    100
) NOT NULL,
    lat DOUBLE PRECISION,
    lng DOUBLE PRECISION,
    CONSTRAINT uk_town_code UNIQUE
(
    code
),
    CONSTRAINT fk_town_county FOREIGN KEY
(
    county_code
) REFERENCES im_ibs_china_county
(
    code
) ON DELETE CASCADE
    );

-- 索引
CREATE INDEX idx_town_county_code ON im_ibs_china_town (county_code);

-- 添加注释
COMMENT
ON TABLE im_ibs_china_town IS '中国行政区划-乡镇/街道表';
COMMENT
ON COLUMN im_ibs_china_town.county_code IS '所属区县代码';

-- ==========================================
-- 5. 村/社区表 (Village/Community)
-- ==========================================
CREATE TABLE IF NOT EXISTS im_ibs_china_village
(
    id
    BIGINT
    PRIMARY
    KEY
    GENERATED
    BY
    DEFAULT AS
    IDENTITY,
    town_code
    BIGINT
    NOT
    NULL,
    code
    BIGINT
    NOT
    NULL,
    name
    VARCHAR
(
    100
) NOT NULL,
    lat DOUBLE PRECISION,
    lng DOUBLE PRECISION,
    CONSTRAINT uk_village_code UNIQUE
(
    code
),
    CONSTRAINT fk_village_town FOREIGN KEY
(
    town_code
) REFERENCES im_ibs_china_town
(
    code
) ON DELETE CASCADE
    );

-- 索引
CREATE INDEX idx_village_town_code ON im_ibs_china_village (town_code);

-- 添加注释
COMMENT
ON TABLE im_ibs_china_village IS '中国行政区划-村/社区表';
COMMENT
ON COLUMN im_ibs_china_village.town_code IS '所属乡镇代码';
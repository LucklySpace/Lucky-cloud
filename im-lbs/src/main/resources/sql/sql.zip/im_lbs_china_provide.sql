INSERT INTO "public"."im_lbs_china_province"
VALUES (1, 110, '北京市', '39.92998577808024', '116.39564503787867');
INSERT INTO "public"."im_lbs_china_province"
VALUES (2, 120, '天津市', '39.143929903310074', '117.21081309155257');
INSERT INTO "public"."im_lbs_china_province"
VALUES (3, 130, '河北省', '38.61383974925108', '115.66143362422224');
INSERT INTO "public"."im_lbs_china_province"
VALUES (4, 140, '山西省', '37.86656599050925', '112.51549586383865');
INSERT INTO "public"."im_lbs_china_province"
VALUES (5, 150, '内蒙古自治区', '43.46823822194904', '114.41586754816612');
INSERT INTO "public"."im_lbs_china_province"
VALUES (6, 210, '辽宁省', '41.62160010595761', '122.75359155771858');
INSERT INTO "public"."im_lbs_china_province"
VALUES (7, 220, '吉林省', '43.67884618524125', '126.26287593077805');
INSERT INTO "public"."im_lbs_china_province"
VALUES (8, 230, '黑龙江省', '47.35659164311141', '128.0474137149926');
INSERT INTO "public"."im_lbs_china_province"
VALUES (9, 310, '上海市', '31.24916171001514', '121.48789948569473');
INSERT INTO "public"."im_lbs_china_province"
VALUES (10, 320, '江苏省', '33.01379716995394', '119.36848893835847');
INSERT INTO "public"."im_lbs_china_province"
VALUES (11, 330, '浙江省', '29.159494120760925', '119.95720242066378');
INSERT INTO "public"."im_lbs_china_province"
VALUES (12, 340, '安徽省', '31.85925241707919', '117.2160052075697');
INSERT INTO "public"."im_lbs_china_province"
VALUES (13, 350, '福建省', '26.050118295660656', '117.98494311990738');
INSERT INTO "public"."im_lbs_china_province"
VALUES (14, 360, '江西省', '27.757258443440836', '115.67608236670434');
INSERT INTO "public"."im_lbs_china_province"
VALUES (15, 370, '山东省', '36.09928992972826', '118.52766339287801');
INSERT INTO "public"."im_lbs_china_province"
VALUES (16, 410, '河南省', '34.157183767956035', '113.48680405752653');
INSERT INTO "public"."im_lbs_china_province"
VALUES (17, 420, '湖北省', '31.209316250139747', '112.41056219213213');
INSERT INTO "public"."im_lbs_china_province"
VALUES (18, 430, '湖南省', '27.695864052356377', '111.720663546476');
INSERT INTO "public"."im_lbs_china_province"
VALUES (19, 440, '广东省', '23.40800372902474', '113.3948175587587');
INSERT INTO "public"."im_lbs_china_province"
VALUES (20, 450, '广西壮族自治区', '23.552254688119405', '108.92427442705878');
INSERT INTO "public"."im_lbs_china_province"
VALUES (21, 460, '海南省', '19.18050080126052', '109.73375548794272');
INSERT INTO "public"."im_lbs_china_province"
VALUES (22, 500, '重庆市', '29.54460610888615', '106.53063501341296');
INSERT INTO "public"."im_lbs_china_province"
VALUES (23, 510, '四川省', '30.36748093795755', '102.89915972360397');
INSERT INTO "public"."im_lbs_china_province"
VALUES (24, 520, '贵州省', '26.902825927796762', '106.7349961033045');
INSERT INTO "public"."im_lbs_china_province"
VALUES (25, 530, '云南省', '24.86421279548333', '101.59295163700766');
INSERT INTO "public"."im_lbs_china_province"
VALUES (26, 540, '西藏自治区', '31.36731540271471', '89.1379816840313');
INSERT INTO "public"."im_lbs_china_province"
VALUES (27, 610, '陕西省', '35.860026261322766', '109.50378929072508');
INSERT INTO "public"."im_lbs_china_province"
VALUES (28, 620, '甘肃省', '38.10326734375233', '102.45762459933961');
INSERT INTO "public"."im_lbs_china_province"
VALUES (29, 630, '青海省', '35.499761004274674', '96.20254367226111');
INSERT INTO "public"."im_lbs_china_province"
VALUES (30, 640, '宁夏回族自治区', '37.32132311229541', '106.15548126505365');
INSERT INTO "public"."im_lbs_china_province"
VALUES (31, 650, '新疆维吾尔自治区', '42.127000957642366', '85.61489933833856');
